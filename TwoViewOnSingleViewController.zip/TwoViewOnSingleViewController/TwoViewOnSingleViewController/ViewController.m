//
//  ViewController.m
//  TwoViewOnSingleViewController
//
//  Created by RASP software solutions on 8/9/16.
//  Copyright © 2016 RASP software solutions. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *orangeView;
@property (weak, nonatomic) IBOutlet UIView *BlueView;
@property (weak, nonatomic) IBOutlet UIButton *BlueButton;
@property (weak, nonatomic) IBOutlet UIButton *OrangeButton;

- (IBAction)BlueAction:(id)sender;
- (IBAction)OrangeAction:(id)sender;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)BlueAction:(id)sender {
    _BlueView.hidden=NO;
    _orangeView.hidden=YES;
}

- (IBAction)OrangeAction:(id)sender {
    _BlueView.hidden=YES;
    _orangeView.hidden=NO;
    
}
@end
