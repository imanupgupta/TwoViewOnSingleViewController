//
//  main.m
//  TwoViewOnSingleViewController
//
//  Created by RASP software solutions on 8/9/16.
//  Copyright © 2016 RASP software solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
