//
//  AppDelegate.h
//  TwoViewOnSingleViewController
//
//  Created by RASP software solutions on 8/9/16.
//  Copyright © 2016 RASP software solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

